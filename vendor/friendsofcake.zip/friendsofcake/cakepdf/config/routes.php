<?php
use Cake\Routing\Router;

Router::extensions(['pdf']);
